<?php
// Simple landing page
require_once __DIR__ . '/header.php';

// if (session_status() === PHP_SESSION_NONE) {
//     session_start();
// }

$user = $_SESSION['user'] ?? null;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>College Authentication System</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="header">
        <div>
          <h1>Auth System</h1>
          <div class="badge">PHP + MySQL (XAMPP)</div>
        </div>
      </div>

      <?php if ($user): ?>
        <div class="msg success">
          <strong>Welcome!</strong>
          <div>Hi, <?= h($user['full_name'] ?? '') ?>.</div>
        </div>
        <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
          <a class="btn" style="display:inline-block; text-align:center;" href="logout.php">Logout</a>
        </div>
      <?php else: ?>
        <div class="msg">
          <strong>Choose an action</strong>
          <div>Register for an account, log in, or reset your password.</div>
        </div>
        <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
          <a class="btn" style="display:inline-block; text-align:center;" href="register.php">Register</a>
          <a class="btn secondary" style="display:inline-block; text-align:center;" href="login.php">Login</a>
          <a class="btn secondary" style="display:inline-block; text-align:center;" href="reset_password.php">Reset Password</a>
        </div>
      <?php endif; ?>

      <div class="footer-links">
        <span>DB name: <code style="color:var(--text)">COMPUTING</code></span>
        <span>Table: <code style="color:var(--text)">users</code></span>
      </div>
    </div>
  </div>
</body>
</html>

