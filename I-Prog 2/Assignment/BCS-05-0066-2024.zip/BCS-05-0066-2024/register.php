<?php
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name      = trim($_POST['full_name'] ?? '');
    $form_username  = trim($_POST['username'] ?? '');
    $email          = trim($_POST['email'] ?? '');
    $form_password  = $_POST['password'] ?? '';
    $confirm        = $_POST['confirm_password'] ?? '';

    // Server-side validation
    if ($full_name === '') {
        $errors[] = 'Full name is required.';
    }

    if ($form_username === '') {
        $errors[] = 'Username is required.';
    }

    if ($email === '') {
        $errors[] = 'Email address is required.';
    }

    if ($form_password === '') {
        $errors[] = 'Password is required.';
    }

    if ($form_username !== '' && !preg_match('/^[A-Za-z0-9_]{3,50}$/', $form_username)) {
        $errors[] = 'Username must be 3-50 characters and contain only letters, numbers, and underscores.';
    }

    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }

    if ($form_password !== '' && strlen($form_password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }

    if ($confirm === '') {
        $errors[] = 'Please confirm your password.';
    } elseif ($form_password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    // Process registration if no errors
    if (!$errors) {
        try {
            $pdo = getPDOConnection();

            // Check if username or email already exists
            $stmt = $pdo->prepare(
                'SELECT user_id FROM users WHERE username = :username OR email = :email LIMIT 1'
            );

            $stmt->execute([
                ':username' => $form_username,
                ':email'    => $email
            ]);

            if ($stmt->fetch()) {
                $errors[] = 'Username or email already exists.';
            } else {
                // Hash password
                $hashedPassword = password_hash($form_password, PASSWORD_DEFAULT);

                // Insert new user
                $stmt = $pdo->prepare(
                    'INSERT INTO users (full_name, username, email, password_hash)
                     VALUES (:full_name, :username, :email, :password_hash)'
                );

                $stmt->execute([
                    ':full_name'     => $full_name,
                    ':username'      => $form_username,
                    ':email'         => $email,
                    ':password_hash' => $hashedPassword,
                ]);

                $success = 'Registration successful. You can now log in.';
            }

        } catch (Throwable $e) {
            $errors[] = $e->getMessage();
        }
    }
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>College Authentication System</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <div class="card">

        <div class="header">
            <div>
                <h1>Register</h1>
                <div class="badge">Create your account</div>
            </div>
            <div>
                <a href="login.php">Login</a>
            </div>
        </div>

        <!-- Error messages -->
        <?php if ($errors): ?>
            <div class="msg error">
                <strong>Fix the following:</strong>
                <ul style="margin:8px 0 0 18px; padding:0;">
                    <?php foreach ($errors as $err): ?>
                        <li><?= h($err) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Success message -->
        <?php if ($success): ?>
            <div class="msg success">
                <strong>Success</strong>
                <div><?= h($success) ?></div>
            </div>
        <?php endif; ?>

        <!-- Registration Form -->
        <form method="post" action="register.php" autocomplete="off" novalidate>
            <label>Full Name</label>
            <input
                type="text"
                name="full_name"
                value="<?= h($_POST['full_name'] ?? '') ?>"
                placeholder="e.g., John Doe"
                required
            />

            <label>Username</label>
            <input
                type="text"
                name="username"
                value="<?= h($_POST['username'] ?? '') ?>"
                placeholder="e.g., john_doe"
                required
            />

            <label>Email Address</label>
            <input
                type="email"
                name="email"
                value="<?= h($_POST['email'] ?? '') ?>"
                placeholder="e.g., john@example.com"
                required
            />

            <label>Password</label>
            <input
                type="password"
                name="password"
                placeholder="Minimum 6 characters"
                required
            />

            <label>Confirm Password</label>
            <input
                type="password"
                name="confirm_password"
                placeholder="Re-enter password"
                required
            />

            <button class="btn" type="submit">Create Account</button>

            <div class="footer-links">
                <span>Already have an account? <a href="login.php">Login</a></span>
                <span><a href="reset_password.php">Forgot password?</a></span>
            </div>
        </form>

    </div>
</div>
</body>
</html>