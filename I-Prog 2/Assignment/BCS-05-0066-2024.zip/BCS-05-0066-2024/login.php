<?php
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db.php';


$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '') $errors[] = 'Username is required.';
    if ($password === '') $errors[] = 'Password is required.';

    if (!$errors) {
        try {
            $pdo = getPDOConnection();
            $stmt = $pdo->prepare('SELECT user_id, full_name, username, password_hash FROM users WHERE username = :username LIMIT 1');
            $stmt->execute([':username' => $username]);
            $user = $stmt->fetch();

            if (!$user || !password_verify($password, $user['password_hash'])) {
                $errors[] = 'Invalid username or password.';
            } else {
                $_SESSION['user'] = [
                    'user_id' => (int)$user['user_id'],
                    'full_name' => $user['full_name'],
                    'username' => $user['username'],
                ];
                header('Location: index.php');
                exit;
            }
        } catch (Throwable $e) {
            $errors[] = 'Login failed. Please try again.';
        }
    }
}

$isLoggedIn = isset($_SESSION['user']);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>College Authentication System</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="header">
        <div>
          <h1>Login</h1>
          <div class="badge">Secure authentication</div>
        </div>
        <div>
          <a href="register.php">Register</a>
        </div>
      </div>

      <?php if ($isLoggedIn): ?>
        <div class="msg success">
          <strong>Welcome!</strong>
          <div>
            Hi, <?= h($_SESSION['user']['full_name'] ?? '') ?>.
          </div>
        </div>
        <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
          <a class="btn" style="display:inline-block; text-align:center;" href="logout.php">Logout</a>
        </div>
      <?php else: ?>
        <?php if ($errors): ?>
          <div class="msg error">
            <strong>Error</strong>
            <ul style="margin:8px 0 0 18px; padding:0;">
              <?php foreach ($errors as $err): ?>
                <li><?= h($err) ?></li>
              <?php endforeach; ?>
            </ul>
          </div>
        <?php endif; ?>

        <form method="post" action="login.php" autocomplete="off" novalidate>
          <label>Username</label>
          <input type="text" name="username" value="<?= h($_POST['username'] ?? '') ?>" placeholder="Your username" required />

          <label>Password</label>
          <input type="password" name="password" placeholder="Your password" required />

          <button class="btn" type="submit">Login</button>

          <div class="footer-links">
            <span>New here? <a href="register.php">Create an account</a></span>
            <span><a href="reset_password.php">Reset password</a></span>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>
</body>
</html>

