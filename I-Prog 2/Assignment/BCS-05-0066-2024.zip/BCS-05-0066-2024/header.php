<?php
if (session_status() === PHP_SESSION_NONE) {
  session_start();
}

function h(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }

