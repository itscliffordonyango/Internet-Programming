<?php
require_once __DIR__ . '/header.php';
require_once __DIR__ . '/db.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $new_password = $_POST['new_password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($email === '') $errors[] = 'Email address is required.';
    if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Invalid email address.';
    }

    if ($new_password === '') $errors[] = 'New password is required.';
    if ($new_password !== '' && strlen($new_password) < 6) {
        $errors[] = 'Password must be at least 6 characters.';
    }

    if ($confirm === '') $errors[] = 'Please confirm your new password.';
    if ($new_password !== '' && $confirm !== '' && $new_password !== $confirm) {
        $errors[] = 'Passwords do not match.';
    }

    if (!$errors) {
        try {
            $pdo = getPDOConnection();
            $stmt = $pdo->prepare('SELECT user_id FROM users WHERE email = :email LIMIT 1');
            $stmt->execute([':email' => $email]);
            $user = $stmt->fetch();

            if (!$user) {
                $errors[] = 'No account found with that email.';
            } else {
                $hash = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare('UPDATE users SET password_hash = :hash WHERE email = :email');
                $stmt->execute([':hash' => $hash, ':email' => $email]);
                $success = 'Password updated successfully. You can log in now.';
            }
        } catch (Throwable $e) {
            $errors[] = 'Reset failed. Please try again.';
        }
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>College Authentication System</title>
  <link rel="stylesheet" href="styles.css" />
</head>
<body>
  <div class="container">
    <div class="card">
      <div class="header">
        <div>
          <h1>Reset Password</h1>
          <div class="badge">Use your registered email</div>
        </div>
        <div>
          <a href="login.php">Login</a>
        </div>
      </div>

      <?php if ($errors): ?>
        <div class="msg error">
          <strong>Fix the following:</strong>
          <ul style="margin:8px 0 0 18px; padding:0;">
            <?php foreach ($errors as $err): ?>
              <li><?= h($err) ?></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>

      <?php if ($success): ?>
        <div class="msg success">
          <strong>Success</strong>
          <div><?= h($success) ?></div>
        </div>
      <?php endif; ?>

      <form method="post" action="reset_password.php" autocomplete="off" novalidate>
        <label>Email Address</label>
        <input type="email" name="email" value="<?= h($_POST['email'] ?? '') ?>" placeholder="e.g., john@example.com" required />

        <label>New Password</label>
        <input type="password" name="new_password" placeholder="Minimum 6 characters" required />

        <label>Confirm New Password</label>
        <input type="password" name="confirm_password" placeholder="Re-enter new password" required />

        <button class="btn" type="submit">Update Password</button>

        <div class="footer-links">
          <span><a href="register.php">Create account</a></span>
          <span><a href="login.php">Back to login</a></span>
        </div>
      </form>
    </div>
  </div>
</body>
</html>

